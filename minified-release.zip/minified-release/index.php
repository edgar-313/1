<!DOCTYPE html>
<html lang="en">
    <?php
    require 'controllers\head.php';
    ?>
<body>
    <?php
    require "templates\header.php";
    ?>
    <?php
    require "templates\promo.php";
    ?>
    <?php
    require "templates\order.php";
    ?>
    <?php
    require "templates\avtopark.php";
    ?>
    <?php
    require "templates\arenda.php";
    ?>
    <?php
    require "templates\premium.php";
    ?>
    <?php
    require "templates\steps.php";
    ?>
    <?php
    require "templates\skidocki.php";
    ?>
    <?php
    require "templates\uslugi.php";
    ?>
    <?php
    require "templates\prichini.php";
    ?>
    <?php
    require "templates\inostran.php";
    ?>
    <?php
    require "templates\logotip.php";
    ?>
    <?php
    require "templates\Voprosi.php";
    ?>
    <?php
    require "templates\Footer.php";
    ?>
</body>
</html>