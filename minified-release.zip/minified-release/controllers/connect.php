<?php
$host = 'localhost'; 
$user = 't925372u_tachki'; 
$password = 'Q%3bGRRI'; 
$db_name = 't925372u_tachki'; 
$link = mysqli_connect($host, $user, $password, $db_name);
?>